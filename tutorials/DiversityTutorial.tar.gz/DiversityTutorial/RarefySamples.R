rarefySamples <- function(otus, stepR){

smax <- max(rowSums(otus))

rsamples <- seq(10, smax, by=stepR)

sizes <- rowSums(otus)
names <- rownames(otus)

snames <- character(0)
diversities <- integer(0)
ssizes <- integer(0)

rare.df <- data.frame(name= character(0), size= integer(0), spec_number = integer(0))
#loop sample sizes
for (rsample in rsamples){
    #rarefy
    rare <- rarefy(otus, rsample, se = FALSE, MARGIN = 1)
    #loop samples
    i = 1
    for (size in sizes){
        if (rsample < size){
            snames <- c(snames, names[i])
            diversities <- c(diversities,rare[[i]])  
            ssizes <- c(ssizes,rsample)
        }
        i = i + 1
    }
}

rare.df <- data.frame(Names=snames,Sizes=ssizes,Diversities=diversities)

return(rare.df)
}
